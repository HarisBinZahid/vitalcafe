export const FIREBASE_CREDENTIALS = {
    apiKey: "AIzaSyClCEJWBiAzTJidavROj6a4aSLON9xCw8s",
    authDomain: "vitalcafe-3c00b.firebaseapp.com",
    databaseURL: "https://vitalcafe-3c00b.firebaseio.com",
    projectId: "vitalcafe-3c00b",
    storageBucket: "vitalcafe-3c00b.appspot.com",
    messagingSenderId: "789289193827"
};
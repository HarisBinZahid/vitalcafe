export interface OrderItem {
    orderername:string;
    orderdesc:string;
    prodtype: string;
    hall: string;
    booth: string;
}